(function(){
  var C=window.Capacitor;
  if(!C||!C.isNativePlatform||!C.isNativePlatform())return;
  var P=C.Plugins||{};
  function safe(f){try{return f()}catch(e){}}
  var st=document.createElement('style');
  st.textContent='body.kb nav,body.kb #rt{display:none!important}body.kb #app{padding-bottom:24px!important}#off{position:fixed;top:env(safe-area-inset-top,0px);inset-inline:0;background:#232932;color:#C6FF00;text-align:center;font:600 12px Barlow,system-ui;padding:4px;z-index:60;display:none}';
  document.head.appendChild(st);
  var b=document.createElement('div');b.id='off';b.textContent='Offline mode – all features still work';document.body.appendChild(b);
  if(P.StatusBar){safe(function(){P.StatusBar.setStyle({style:'DARK'});P.StatusBar.setBackgroundColor({color:'#0B0D10'})})}
  if(P.Keyboard){safe(function(){
    P.Keyboard.addListener('keyboardWillShow',function(){document.body.classList.add('kb')});
    P.Keyboard.addListener('keyboardDidHide',function(){document.body.classList.remove('kb')});
  })}
  if(P.Network){safe(function(){
    var show=function(s){b.style.display=s.connected?'none':'block'};
    P.Network.getStatus().then(show);P.Network.addListener('networkStatusChange',show);
  })}
  if(P.SplashScreen){safe(function(){setTimeout(function(){P.SplashScreen.hide()},900)})}
})();
