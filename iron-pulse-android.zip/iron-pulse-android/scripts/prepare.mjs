import fs from 'node:fs';
fs.mkdirSync('www',{recursive:true});
let h=fs.readFileSync('src-web/index.html','utf8');
const n=fs.readFileSync('scripts/native.js','utf8');
if(!h.includes('id="native-bridge"')) h=h.replace('</body>',`<script id="native-bridge">${n}</script></body>`);
fs.writeFileSync('www/index.html',h);
console.log('www/index.html ready');
