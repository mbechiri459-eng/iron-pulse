import fs from 'node:fs';
const p='android/app/src/main/AndroidManifest.xml';
let m=fs.readFileSync(p,'utf8');
if(!m.includes('screenOrientation')) m=m.replace('<activity','<activity\n            android:screenOrientation="portrait"');
fs.writeFileSync(p,m);
const s='android/app/src/main/res/values/styles.xml';
if(fs.existsSync(s)){let x=fs.readFileSync(s,'utf8');x=x.replace(/(<style name="AppTheme\.NoActionBarLaunch"[^>]*>)/,'$1\n        <item name="android:windowBackground">#0B0D10</item>');fs.writeFileSync(s,x)}
console.log('Android manifest and theme patched');
