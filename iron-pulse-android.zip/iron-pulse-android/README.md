# IRON PULSE – Android (Capacitor)
Requirements: Node 20+, JDK 21, Android Studio (SDK Platform 35 + Build-Tools), ANDROID_HOME set. Internet only for first install.

    npm install
    npm run android:add     # creates android/, patches portrait + dark theme, generates icon + splash
    npm run apk             # builds android/app/build/outputs/apk/debug/app-debug.apk
    npm run android:open    # optional: open in Android Studio

Install on phone: enable USB debugging, then `adb install -r android/app/build/outputs/apk/debug/app-debug.apk`, or copy the APK to the phone and open it (allow "install unknown apps").

Release: create a keystore (`keytool -genkey -v -keystore ironpulse.jks -alias ironpulse -keyalg RSA -keysize 2048 -validity 10000`), add a signingConfig in android/app/build.gradle, then `npm run apk:release`, or build an AAB for Play Store in Android Studio (Build > Generate Signed Bundle). Never commit the keystore.

Permissions: only INTERNET and ACCESS_NETWORK_STATE (added by the Network plugin). The app works offline; user data lives in WebView localStorage.
Using a real Vite project: set webDir to your dist folder, install the same plugins, and port scripts/native.js into src/main.ts.
Fonts: Barlow loads from Google Fonts when online and falls back to system fonts offline; bundle the .woff2 files to make them offline too.
